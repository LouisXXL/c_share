﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// User 的摘要描述
/// </summary>
public class User
{
    // Auto-Impl Properties for trivial get and set
    public int id { get; set; }
    public string name { get; set; }
    public string email { get; set; }
    public string address { get; set; }
    public string mobile { get; set; }
}
